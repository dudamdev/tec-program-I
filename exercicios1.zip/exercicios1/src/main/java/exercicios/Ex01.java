/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicios;

/**
 *
 * @author 1091392223010
 */
public class Ex01 {
    public static void main(String[] args) {
        int soma = 0;
        for(int i = 1; i <= 100; i++) {
            soma += i;
        }
        
        System.out.printf("A soma dos números de 1 a 100 é: %d%n", soma);
    }
}
