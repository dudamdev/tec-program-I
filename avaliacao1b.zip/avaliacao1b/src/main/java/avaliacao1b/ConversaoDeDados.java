/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package avaliacao1b;

/**
 *
 * @author dudaa
 */
public class ConversaoDeDados {
    
    public static double kmEmMetros (double km) {
        return km * 1000;
    }
    
    public static double litrosEmDecilitros(double litros) {
        return litros * 10;
    }
    
    public static double metroCubicosEmPesCubicos(double mCubicos) {
        return mCubicos * 35.31;
    }
    
    public static double barrilEmDecalitros(double barril) {
        return barril * 16.36;
    }
    
    public static double barrilEmLitros(double barril) {
        return barril * 163.65;
    }
}

